public class RobotInterruptedException extends RuntimeException{}
